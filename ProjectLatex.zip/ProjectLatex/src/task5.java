// Metoda usuwająco postać
    public static void deleteCharacter() throws LastCharacterException{
        try {
            int nullCounter = 0;
            for (Character character : Data.characters) {
                if (character == null) nullCounter++;
            }
            if(nullCounter >= 3) throw new LastCharacterException("Nie można usunąć ostatniej postaci!");
            System.out.println("Wybierz postać do usunięcia:");
            for (int i = 0; i < Data.characters.length; i++) {
                if (Data.characters[i] == null) continue;
                else {
                    System.out.println((i + 1) + ". " + Data.characters[i].getName());
                }
            }
            switch (Data.readIntInput.nextInt()) {
                case 1:
                    Data.characters[0] = null;
                    break;
                case 2:
                    Data.characters[1] = null;
                    break;
                case 3:
                    Data.characters[2] = null;
                    break;
                case 4:
                    Data.characters[3] = null;
                    break;
                default:
                    break;
            }
        }
        catch (LastCharacterException e){
            e.printStackTrace();
        }
    }