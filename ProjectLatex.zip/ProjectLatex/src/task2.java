// Listy i tablica przechowujące dane o przedmiotach, przeciwnikach,
    // drużynie oraz ewkipunku
    static Character[] characters = new Character[4];
    static ArrayList<AItem> itemList = new ArrayList<>();
    static ArrayList<Enemy> enemyList = new ArrayList<>();
    static ArrayList<AItem> inventory = new ArrayList<>();
    static int money = 100;

    // Statyczne pola do wczytywania danych od użytkownika
    static Scanner readStringInput = new Scanner(System.in);
    static Scanner readIntInput = new Scanner(System.in);