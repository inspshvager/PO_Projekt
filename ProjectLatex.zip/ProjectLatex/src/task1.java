// Metoda rozpoczynająca nową grę
    public static void newGame(){
        System.out.println("Stwórz 4 postacie:");
        Data.characters[0] = UserOperations.createCharacter();
        Data.characters[1] = UserOperations.createCharacter();
        Data.characters[2] = UserOperations.createCharacter();
        Data.characters[3] = UserOperations.createCharacter();
        for (Character x : Data.characters){
            System.out.println(x.getName());
        }
    }