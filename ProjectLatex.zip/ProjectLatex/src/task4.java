// Metoda do tworzenia nowej postaci z poziomu użytkownika
    public static Character createCharacter() {
        System.out.println("Podaj imię postaci");
        characterName = Data.readStringInput.nextLine();
        do{
            System.out.println("Wybierze klasę postaci");
            System.out.println("1. Rycerz\n2. Czarny Mag\n3. Biały Mag\n4. Złodziej");
            switch (Data.readIntInput.nextInt()) {
                case 1:
                    return new Character(characterName, 200, 20, 15, 20, 5, 15, 10, 0);
                case 2:
                    return new Character(characterName, 100, 50, 5, 10, 25, 20, 15, 0);
                case 3:
                    return new Character(characterName, 125, 40, 5, 15, 20, 25, 12, 0);
                case 4:
                    return new Character(characterName, 150, 30, 15, 15, 10, 15, 20, 0);
                default:
                    System.out.println("Niepoprawna odpowiedź, wprowadź dane jeszcze raz.");
            }
        }
        while (true);
    }